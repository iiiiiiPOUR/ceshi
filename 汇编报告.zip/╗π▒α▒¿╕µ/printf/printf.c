void printf(char * str,...);
main()
{
printf("%c  %d",'v',23);
printf("     %d     %d",-15,-32768);
}

void show(char * str,...)
{
int xianshi=160*20+6;char yu;int jishu=0;
char ch;int i;char *p;
int c;int a=0;int b=0;
while(*str!=0)
{
	if(*str=='%')
	{
		str++;
		if(*str=='c')
		{
			*(char far *)(0xb8000000+xianshi+a+a)=*(int *)(_BP+6+b+b);
			a++;b++;
		}
		if(*str=='d')
		{
			str++;
			if(*str=='-')
			{
				*(char far *)(0xb8000000+xianshi+a+a)=*(int *)(_BP+6+b+b);
				a++;b++;
			}
			else
			{
				c=*(int *)(_BP+6+b+b);
				if(c==0)
				{
					*(char far *)(0xb8000000+xianshi+a+a)=0x30;	
					a++;
				}
				while(c!=0)
				{
					yu=c%10;c=c/10;
					*p++=yu;jishu++;
				}
				for(;jishu>0;jishu--)
				{
					*(char far *)(0xb8000000+xianshi+a+a)=*(p-1)+0x30;
					a++;*p--;
				}
				b++;
			}
		}
	}	
	else
	{
		*(char far *)(0xb8000000+xianshi+a+a)=*str;
		a++;
	}
	str++;
}
}